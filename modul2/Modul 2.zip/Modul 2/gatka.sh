echo 'nameserver 10.64.1.2' > /etc/resolv.conf
cat /etc/resolv.conf