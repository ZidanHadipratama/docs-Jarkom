# ~/.bashrc: executed by bash(1) for non-login shells.
# see /usr/share/doc/bash/examples/startup-files (in the package bash-doc)
# for examples

# If not running interactively, don't do anything
[ -z "$PS1" ] && return

# don't put duplicate lines in the history. See bash(1) for more options
# ... or force ignoredups and ignorespace
HISTCONTROL=ignoredups:ignorespace

# append to the history file, don't overwrite it
shopt -s histappend

# for setting history length see HISTSIZE and HISTFILESIZE in bash(1)
HISTSIZE=1000
HISTFILESIZE=2000

# check the window size after each command and, if necessary,
# update the values of LINES and COLUMNS.
shopt -s checkwinsize

# make less more friendly for non-text input files, see lesspipe(1)
[ -x /usr/bin/lesspipe ] && eval "$(SHELL=/bin/sh lesspipe)"

# set variable identifying the chroot you work in (used in the prompt below)
if [ -z "$debian_chroot" ] && [ -r /etc/debian_chroot ]; then
    debian_chroot=$(cat /etc/debian_chroot)
fi

# set a fancy prompt (non-color, unless we know we "want" color)
case "$TERM" in
    xterm-color) color_prompt=yes;;
esac

# uncomment for a colored prompt, if the terminal has the capability; turned
# off by default to not distract the user: the focus in a terminal window
# should be on the output of commands, not on the prompt
#force_color_prompt=yes

if [ -n "$force_color_prompt" ]; then
    if [ -x /usr/bin/tput ] && tput setaf 1 >&/dev/null; then
        # We have color support; assume it's compliant with Ecma-48
        # (ISO/IEC-6429). (Lack of such support is extremely rare, and such
        # a case would tend to support setf rather than setaf.)
        color_prompt=yes
    else
        color_prompt=
    fi
fi

if [ "$color_prompt" = yes ]; then
    PS1='${debian_chroot:+($debian_chroot)}\[\033[01;32m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ '
else
    PS1='${debian_chroot:+($debian_chroot)}\u@\h:\w\$ '
fi
unset color_prompt force_color_prompt

# If this is an xterm set the title to user@host:dir
case "$TERM" in
xterm*|rxvt*)
    PS1="\[\e]0;${debian_chroot:+($debian_chroot)}\u@\h: \w\a\]$PS1"
    ;;
*)
    ;;
esac

# enable color support of ls and also add handy aliases
if [ -x /usr/bin/dircolors ]; then
    test -r ~/.dircolors && eval "$(dircolors -b ~/.dircolors)" || eval "$(dircolors -b)"
    alias ls='ls --color=auto'
    #alias dir='dir --color=auto'
    #alias vdir='vdir --color=auto'

    alias grep='grep --color=auto'
    alias fgrep='fgrep --color=auto'
    alias egrep='egrep --color=auto'
fi

# some more ls aliases
alias ll='ls -alF'
alias la='ls -A'
alias l='ls -CF'

# Alias definitions.
# You may want to put all your additions into a separate file like
# ~/.bash_aliases, instead of adding them here directly.
# See /usr/share/doc/bash-doc/examples in the bash-doc package.

if [ -f ~/.bash_aliases ]; then
    . ~/.bash_aliases
fi

# enable programmable completion features (you don't need to enable
# this, if it's already enabled in /etc/bash.bashrc and /etc/profile
# sources /etc/bash.bashrc).
#if [ -f /etc/bash_completion ] && ! shopt -oq posix; then
#    . /etc/bash_completion
#fi


echo "nameserver 192.168.122.1" > /etc/resolv.conf
apt-get update
apt-get install bind9 -y

# edit file named.conf.local
echo 'zone "airdrop.it01.com" {
    type master;
    also-notify { 10.64.3.2; };
    allow-transfer { 10.64.3.2; };
    file "/etc/bind/airdrop/airdrop.it01.com";
};

zone "redzone.it01.com" {
    type master;
    also-notify { 10.64.3.2; };
    allow-transfer { 10.64.3.2; };
    file "/etc/bind/redzone/redzone.it01.com";
};

zone "loot.it01.com" {
    type master;
    also-notify { 10.64.3.2; };
    allow-transfer { 10.64.3.2; };
    file "/etc/bind/loot/loot.it01.com";
};

zone "4.64.10.in-addr.arpa" {
    type master;
    file "/etc/bind/reverse/4.64.10.in-addr.arpa";
};

zone "mylta.it01.com" {
	type master;
	file "/etc/bind/jarkom/mylta.it01.com";
};

zone "tamat.it01.com" {
	type master;
	file "/etc/bind/jarkom/tamat.it01.com";
};' > /etc/bind/named.conf.local



# Membuat folder baru untuk masing-masing domain (no 2-6)
mkdir /etc/bind/airdrop
mkdir /etc/bind/redzone
mkdir /etc/bind/loot
mkdir /etc/bind/reverse

# Copy file db.local ke file konfigurasi masing-masing domain
cp /etc/bind/db.local /etc/bind/airdrop/airdrop.it01.com
cp /etc/bind/db.local /etc/bind/redzone/redzone.it01.com
cp /etc/bind/db.local /etc/bind/loot/loot.it01.com
cp /etc/bind/db.local /etc/bind/reverse/4.64.10.in-addr.arpa

# Edit file /etc/bind/airdrop/airdrop.it01.com
echo ';
;
; BIND data file for local loopback interface
;
$TTL    604800
@       IN      SOA     airdrop.it01.com. root.airdrop.it01.com. (
                              2         ; Serial
                         604800         ; Refresh
                          86400         ; Retry
                        2419200         ; Expire
                         604800 )       ; Negative Cache TTL
;
@       IN      NS      airdrop.it01.com.
@       IN      A       10.64.4.3   ; IP Stalber
@       IN      AAAA    ::1
www     IN      CNAME   airdrop.it01.com.
medkit  IN      A       10.64.4.4       ; IP Lipovka' > /etc/bind/airdrop/airdrop.it01.com

# Edit file /etc/bind/redzone/redzone.it01.com
echo ';
; BIND data file for local loopback interface
;
$TTL    604800
@       IN      SOA     redzone.it01.com. root.redzone.it01.com. (
                              2         ; Serial
                         604800         ; Refresh
                          86400         ; Retry
                        2419200         ; Expire
                         604800 )       ; Negative Cache TTL
;
@       IN      NS      redzone.it01.com.
@       IN      A       10.64.4.2   ; IP Severny
@       IN      AAAA    ::1
www     IN      CNAME   redzone.it01.com.' > /etc/bind/redzone/redzone.it01.com

# Edit file /etc/bind/loot/loot.it01.com
echo ';
; BIND data file for local loopback interface
;
$TTL    604800
@       IN      SOA     loot.it01.com. root.loot.it01.com. (
                              2         ; Serial
                         604800         ; Refresh
                          86400         ; Retry
                        2419200         ; Expire
                         604800 )       ; Negative Cache TTL
;
@       IN      NS      loot.it01.com.
@       IN      A       10.64.4.5   ; IP Mylta
@       IN      AAAA    ::1
www     IN      CNAME   loot.it01.com.' > /etc/bind/loot/loot.it01.com

# Edit file /etc/bind/reverse/4.64.10.in-addr.arpa
echo ';
; BIND data file for local loopback interface
;
$TTL    604800
@       IN      SOA     redzone.it01.com. root.redzone.it01.com. (
                              2         ; Serial
                         604800         ; Refresh
                          86400         ; Retry
                        2419200         ; Expire
                         604800 )       ; Negative Cache TTL
;
4.64.10.in-addr.arpa.   IN      NS      redzone.it01.com.
2       IN      PTR     redzone.it01.com.       ; Byte ke 4 nya Severny' > /etc/bind/reverse/4.64.10.in-addr.arpa

# Buat folder baru siren
mkdir /etc/bind/siren

# Menyalin file redzone ke siren
cp /etc/bind/redzone/redzone.it01.com /etc/bind/siren/siren.redzone.it01.com

# edit file siren.redzone.it01.com
echo ';
; BIND data file for local loopback interface
;
$TTL    604800
@       IN      SOA     redzone.it01.com. root.redzone.it01.com. (
                              2         ; Serial
                         604800         ; Refresh
                          86400         ; Retry
                        2419200         ; Expire
                         604800 )       ; Negative Cache TTL
;
@       IN      NS      redzone.it01.com.
@       IN      A       10.64.4.2 ; IP Severny
www     IN      CNAME   redzone.it01.com.
siren   IN      A       10.64.3.2 ; IP Georgopol
ns1     IN      A       10.64.3.2 ; IP Georgopol
siren   IN      NS      ns1
@       IN      AAAA    ::1' > /etc/bind/siren/siren.redzone.it01.com

# edit file named.conf.options
cat << EOF > /etc/bind/named.conf.options
options {
        directory "/var/cache/bind";

        // If there is a firewall between you and nameservers you want
        // to talk to, you may need to fix the firewall to allow multiple
        // ports to talk.  See http://www.kb.cert.org/vuls/id/800113

        // If your ISP provided one or more IP addresses for stable
        // nameservers, you probably want to use them as forwarders.
        // Uncomment the following block, and insert the addresses replacing
        // the all-0's placeholder.

        forwarders {
              192.168.122.1;
        };

        //========================================================================
        // If BIND logs error messages about the root key being expired,
        // you will need to update your keys.  See https://www.isc.org/bind-keys
        //========================================================================
        // dnssec-validation auto;

        auth-nxdomain no;    # conform to RFC1035
        listen-on-v6 { any; };
        allow-query{any;};
};
EOF

service bind9 restart

echo "nameserver 10.64.1.2" > /etc/resolv.conf


# ZIDANNNN-------------------------------------------
mkdir /etc/bind/jarkom
cp /etc/bind/db.local /etc/bind/jarkom/tamat.it01.com
cp /etc/bind/db.local /etc/bind/jarkom/mylta.it01.com
cp /etc/bind/db.local /etc/bind/jarkom/4.64.10.in-addr.arpa
cat << 'EOF' > /etc/bind/jarkom/mylta.it01.com
;
; BIND data file for local loopback interface
;
$TTL    604800
@       IN      SOA     mylta.it01.com. root.mylta.it01.com. (
                              2         ; Serial
                         604800         ; Refresh
                          86400         ; Retry
                        2419200         ; Expire
                         604800 )       ; Negative Cache TTL
;
mylta.it01.com.       IN      NS      ns.mylta.it01.com.
ns.mylta.it01.com.    IN      A       10.64.4.5
mylta.it01.com.       IN      A       10.64.4.5
www                   IN      CNAME   mylta.it01.com.
mylta.it01.com.       IN      AAAA    ::1
EOF
cat << 'EOF' > /etc/bind/jarkom/4.64.10.in-addr.arpa
;
; BIND data file for local loopback interface
;
$TTL    604800
@       IN      SOA     mylta.it01.com. root.mylta.it01.com. (
                              2         ; Serial
                         604800         ; Refresh
                          86400         ; Retry
                        2419200         ; Expire
                         604800 )       ; Negative Cache TTL
;
@                          IN      NS      mylta.it01.com.
5.4.64.10.in-addr.arpa.    IN      PTR     mylta.it01.com.
EOF
cat << 'EOF' > /etc/bind/jarkom/tamat.it01.com
;
; BIND data file for local loopback interface
;
$TTL    604800
@       IN      SOA     tamat.it01.com. root.tamat.it01.com. (
                              2         ; Serial
                         604800         ; Refresh
                          86400         ; Retry
                        2419200         ; Expire
                         604800 )       ; Negative Cache TTL
;
tamat.it01.com.       IN      NS      ns.tamat.it01.com.
ns.tamat.it01.com.    IN      A       10.64.4.3
tamat.it01.com.       IN      A       10.64.4.3
www                   IN      CNAME   tamat.it01.com.
tamat.it01.com.       IN      AAAA    ::1
EOF
service bind9 restart

# ------------------gabungin reverse dns---------------------------
echo 'zone "airdrop.it01.com" {
    type master;
    also-notify { 10.64.3.2; };
    allow-transfer { 10.64.3.2; };
    file "/etc/bind/airdrop/airdrop.it01.com";
};

zone "redzone.it01.com" {
    type master;
    also-notify { 10.64.3.2; };
    allow-transfer { 10.64.3.2; };
    file "/etc/bind/redzone/redzone.it01.com";
};

zone "loot.it01.com" {
    type master;
    also-notify { 10.64.3.2; };
    allow-transfer { 10.64.3.2; };
    file "/etc/bind/loot/loot.it01.com";
};

zone "4.64.10.in-addr.arpa" {
    type master;
    file "/etc/bind/reverse/4.64.10.in-addr.arpa";
};

zone "mylta.it01.com" {
	type master;
	file "/etc/bind/jarkom/mylta.it01.com";
};

zone "tamat.it01.com" {
	type master;
	file "/etc/bind/jarkom/tamat.it01.com";
};

zone "5.4.64.10.in-addr.arpa" {
	type master;
	file "/etc/bind/reverse/5.4.64.10.in-addr.arpa";
};' > /etc/bind/named.conf.local

cat << 'EOF' > /etc/bind/reverse/5.4.64.10.in-addr.arpa
;
; BIND data file for local loopback interface
;
$TTL    604800
@       IN      SOA     mylta.it01.com. root.mylta.it01.com. (
                              2         ; Serial
                         604800         ; Refresh
                          86400         ; Retry
                        2419200         ; Expire
                         604800 )       ; Negative Cache TTL
;
@                          IN      NS      mylta.it01.com.
5.4.64.10.in-addr.arpa.    IN      PTR     mylta.it01.com.
EOF
service bind9 restart