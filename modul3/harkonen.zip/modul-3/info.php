<?php
    phpinfo()
?>